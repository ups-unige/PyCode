""" __init__.py file
Author: Mascelli Leonardo
Last Edited: 19-09-2023

The only purpose of this file is to make the interpreter treat this folder as
a module.
"""
